import Clutter from 'gi://Clutter'
import Gio from 'gi://Gio'
import GLib from 'gi://GLib'
import GObject from 'gi://GObject'
import Meta from 'gi://Meta'
import Shell from 'gi://Shell'
import St from 'gi://St'

import {Extension, gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js'
import * as Main from 'resource:///org/gnome/shell/ui/main.js'
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js'
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js'

const UUID = 'wayland-autoclicker@anotherone'

const KEY_RECORD_SHORTCUT = 'record-shortcut'
const KEY_PLAYBACK_SHORTCUT = 'playback-shortcut'

const PORTAL_DESTINATION = 'org.freedesktop.portal.Desktop'
const PORTAL_OBJECT_PATH = '/org/freedesktop/portal/desktop'
const PORTAL_REMOTE_DESKTOP_IFACE = 'org.freedesktop.portal.RemoteDesktop'
const PORTAL_REQUEST_IFACE = 'org.freedesktop.portal.Request'
const PORTAL_SESSION_IFACE = 'org.freedesktop.portal.Session'

const DEVICE_KEYBOARD = 1
const DEVICE_POINTER = 2

const BUTTON_RELEASED = 0
const BUTTON_PRESSED = 1
const KEY_RELEASED = 0
const KEY_PRESSED = 1

const BUTTON_TO_PORTAL_CODE = new Map([
    [1, 272],
    [2, 274],
    [3, 273],
])

const STATUS = {
    IDLE: 'idle',
    RECORDING: 'recording',
    PREPARING: 'preparing',
    PLAYING: 'playing',
    ERROR: 'error',
}

function describeError(error) {
    if (error instanceof Error)
        return error.message

    return String(error)
}

function unpackVariantDict(dict) {
    return Object.fromEntries(
        Object.entries(dict).map(([key, variant]) => [key, variant.unpack()]))
}

function formatShortcut(settings, key) {
    const shortcuts = settings.get_strv(key).filter(Boolean)
    return shortcuts.length > 0 ? shortcuts.join(', ') : _('Disabled')
}

function formatEventCount(count) {
    return `${count} ${count === 1 ? _('event') : _('events')}`
}

function waitMs(delayMs) {
    return new Promise(resolve => {
        if (delayMs <= 0) {
            resolve()
            return
        }

        GLib.timeout_add(GLib.PRIORITY_DEFAULT, delayMs, () => {
            resolve()
            return GLib.SOURCE_REMOVE
        })
    })
}

function callDBus(connection, destination, objectPath, interfaceName, methodName,
    parameters, replyType = null) {
    return new Promise((resolve, reject) => {
        connection.call(
            destination,
            objectPath,
            interfaceName,
            methodName,
            parameters,
            replyType,
            Gio.DBusCallFlags.NONE,
            -1,
            null,
            (source, result) => {
                try {
                    resolve(source.call_finish(result))
                } catch (error) {
                    reject(error)
                }
            })
    })
}

class PortalRemoteDesktopSession {
    constructor(onClosed) {
        this._onClosed = onClosed
        this._connection = Gio.DBus.session
        this._sessionHandle = null
        this._sessionClosedSignalId = 0
        this._startPromise = null
        this._stopRequested = false
    }

    async start() {
        this._stopRequested = false

        if (this._sessionHandle)
            return

        if (!this._startPromise) {
            this._startPromise = this._startInternal().finally(() => {
                this._startPromise = null
            })
        }

        return this._startPromise
    }

    async stop() {
        this._stopRequested = true
        await this._closeSession()
    }

    async movePointer(dx, dy) {
        if (!this._sessionHandle)
            throw new Error(_('No virtual input session is active.'))

        if (dx === 0 && dy === 0)
            return

        await callDBus(
            this._connection,
            PORTAL_DESTINATION,
            PORTAL_OBJECT_PATH,
            PORTAL_REMOTE_DESKTOP_IFACE,
            'NotifyPointerMotion',
            new GLib.Variant('(oa{sv}dd)', [
                this._sessionHandle,
                {},
                dx,
                dy,
            ]),
            new GLib.VariantType('()'))
    }

    async notifyPointerButton(buttonCode, state) {
        if (!this._sessionHandle)
            throw new Error(_('No virtual input session is active.'))

        await callDBus(
            this._connection,
            PORTAL_DESTINATION,
            PORTAL_OBJECT_PATH,
            PORTAL_REMOTE_DESKTOP_IFACE,
            'NotifyPointerButton',
            new GLib.Variant('(oa{sv}iu)', [
                this._sessionHandle,
                {},
                buttonCode,
                state,
            ]),
            new GLib.VariantType('()'))
    }

    async notifyKeyboardKeycode(keycode, state) {
        if (!this._sessionHandle)
            throw new Error(_('No virtual input session is active.'))

        await callDBus(
            this._connection,
            PORTAL_DESTINATION,
            PORTAL_OBJECT_PATH,
            PORTAL_REMOTE_DESKTOP_IFACE,
            'NotifyKeyboardKeycode',
            new GLib.Variant('(oa{sv}iu)', [
                this._sessionHandle,
                {},
                keycode,
                state,
            ]),
            new GLib.VariantType('()'))
    }

    async notifyKeyboardKeysym(keysym, state) {
        if (!this._sessionHandle)
            throw new Error(_('No virtual input session is active.'))

        await callDBus(
            this._connection,
            PORTAL_DESTINATION,
            PORTAL_OBJECT_PATH,
            PORTAL_REMOTE_DESKTOP_IFACE,
            'NotifyKeyboardKeysym',
            new GLib.Variant('(oa{sv}iu)', [
                this._sessionHandle,
                {},
                keysym,
                state,
            ]),
            new GLib.VariantType('()'))
    }

    destroy() {
        this._onClosed = null
        void this.stop()
    }

    async _startInternal() {
        const createToken = this._newToken('create')
        const sessionToken = this._newToken('session')
        const createResults = await this._callPortalRequest(
            'CreateSession',
            new GLib.Variant('(a{sv})', [{
                handle_token: new GLib.Variant('s', createToken),
                session_handle_token: new GLib.Variant('s', sessionToken),
            }]),
            new GLib.VariantType('(o)'),
            createToken)

        const sessionHandle = createResults.session_handle
        if (!sessionHandle)
            throw new Error(_('GNOME did not return a remote desktop session handle.'))

        this._sessionHandle = sessionHandle

        if (this._stopRequested) {
            await this._closeSession()
            throw new Error(_('Macro playback start was cancelled.'))
        }

        const selectToken = this._newToken('select')
        await this._callPortalRequest(
            'SelectDevices',
            new GLib.Variant('(oa{sv})', [sessionHandle, {
                handle_token: new GLib.Variant('s', selectToken),
                types: new GLib.Variant('u', DEVICE_KEYBOARD | DEVICE_POINTER),
            }]),
            new GLib.VariantType('(o)'),
            selectToken)

        if (this._stopRequested) {
            await this._closeSession()
            throw new Error(_('Macro playback start was cancelled.'))
        }

        const startToken = this._newToken('start')
        const startResults = await this._callPortalRequest(
            'Start',
            new GLib.Variant('(osa{sv})', [sessionHandle, '', {
                handle_token: new GLib.Variant('s', startToken),
            }]),
            new GLib.VariantType('(o)'),
            startToken)

        const devices = startResults.devices ?? 0
        const grantedDevices = DEVICE_KEYBOARD | DEVICE_POINTER
        if ((devices & grantedDevices) !== grantedDevices) {
            await this._closeSession()
            throw new Error(_('GNOME did not grant keyboard and pointer access.'))
        }

        this._watchSession(sessionHandle)
    }

    _newToken(prefix) {
        const randomPart = GLib.uuid_string_random().replaceAll('-', '_')
        return `${prefix}_${randomPart}`
    }

    _makeRequestPath(token) {
        const sender = this._connection.get_unique_name()
            .replace(':', '')
            .replaceAll('.', '_')

        return `/org/freedesktop/portal/desktop/request/${sender}/${token}`
    }

    async _callPortalRequest(methodName, parameters, replyType, handleToken) {
        let requestPath = this._makeRequestPath(handleToken)

        return new Promise((resolve, reject) => {
            let subscriptionId = 0
            let completed = false

            const subscribe = path => {
                subscriptionId = this._connection.signal_subscribe(
                    PORTAL_DESTINATION,
                    PORTAL_REQUEST_IFACE,
                    'Response',
                    path,
                    null,
                    Gio.DBusSignalFlags.NONE,
                    (_connection, _sender, _path, _iface, _signal, responseParams) => {
                        if (completed)
                            return

                        completed = true
                        this._connection.signal_unsubscribe(subscriptionId)

                        const [response, responseResults] = responseParams.deepUnpack()
                        if (response === 0) {
                            resolve(unpackVariantDict(responseResults))
                            return
                        }

                        if (response === 1) {
                            reject(new Error(_('The GNOME permission prompt was cancelled.')))
                            return
                        }

                        reject(new Error(_('The GNOME remote desktop request failed.')))
                    })
            }

            subscribe(requestPath)

            callDBus(
                this._connection,
                PORTAL_DESTINATION,
                PORTAL_OBJECT_PATH,
                PORTAL_REMOTE_DESKTOP_IFACE,
                methodName,
                parameters,
                replyType)
                .then(result => {
                    const [returnedRequestPath] = result.deepUnpack()
                    if (returnedRequestPath === requestPath || completed)
                        return

                    this._connection.signal_unsubscribe(subscriptionId)
                    requestPath = returnedRequestPath
                    subscribe(requestPath)
                })
                .catch(error => {
                    if (completed)
                        return

                    completed = true
                    this._connection.signal_unsubscribe(subscriptionId)
                    reject(error)
                })
        })
    }

    _watchSession(sessionHandle) {
        this._unwatchSession()
        this._sessionClosedSignalId = this._connection.signal_subscribe(
            PORTAL_DESTINATION,
            PORTAL_SESSION_IFACE,
            'Closed',
            sessionHandle,
            null,
            Gio.DBusSignalFlags.NONE,
            () => {
                this._sessionHandle = null
                this._unwatchSession()

                if (this._onClosed)
                    this._onClosed()
            })
    }

    _unwatchSession() {
        if (!this._sessionClosedSignalId)
            return

        this._connection.signal_unsubscribe(this._sessionClosedSignalId)
        this._sessionClosedSignalId = 0
    }

    async _closeSession() {
        const sessionHandle = this._sessionHandle
        if (!sessionHandle)
            return

        this._sessionHandle = null
        this._unwatchSession()

        try {
            await callDBus(
                this._connection,
                PORTAL_DESTINATION,
                sessionHandle,
                PORTAL_SESSION_IFACE,
                'Close',
                null,
                new GLib.VariantType('()'))
        } catch (error) {
            logError(error, `${UUID}: failed to close portal session`)
        }
    }
}

const MacroIndicator = GObject.registerClass(
class MacroIndicator extends PanelMenu.Button {
    _init(extension) {
        super._init(0.0, _('Wayland Macro Recorder'))

        this._extension = extension
        this._settings = extension.getSettings()
        this._session = new PortalRemoteDesktopSession(() => {
            if (this._status !== STATUS.PREPARING && this._status !== STATUS.PLAYING)
                return

            void this._stopFromError(new Error(_('GNOME closed the virtual input session.')))
        })

        this._status = STATUS.IDLE
        this._lastError = ''
        this._macroEvents = []
        this._captureSignalId = 0
        this._lastRecordTime = null
        this._lastPointerX = 0
        this._lastPointerY = 0
        this._playbackSerial = 0
        this._destroyed = false

        this.add_style_class_name('macro-panel-button')

        const buttonBox = new St.BoxLayout({
            style_class: 'panel-status-menu-box',
        })

        this._icon = new St.Icon({
            icon_name: 'input-keyboard-symbolic',
            style_class: 'system-status-icon',
        })
        buttonBox.add_child(this._icon)

        this._dot = new St.Widget({
            style_class: 'macro-active-dot',
        })
        buttonBox.add_child(this._dot)

        this.add_child(buttonBox)

        this._buildMenu()
        this._bindSettings()
        this._rebindShortcuts()
        this._syncUi()
    }

    _buildMenu() {
        this._statusItem = new PopupMenu.PopupBaseMenuItem({
            reactive: false,
            can_focus: false,
        })

        const statusBox = new St.BoxLayout({
            vertical: true,
            x_expand: true,
            style_class: 'macro-menu-heading',
        })

        this._statusTitle = new St.Label({
            text: _('Wayland Macro Recorder'),
            style_class: 'macro-menu-title',
            x_expand: true,
        })
        statusBox.add_child(this._statusTitle)

        this._statusDescription = new St.Label({
            style_class: 'macro-menu-subtitle',
            x_expand: true,
        })
        statusBox.add_child(this._statusDescription)

        this._statusItem.add_child(statusBox)
        this.menu.addMenuItem(this._statusItem)
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem())

        this._macroInfoLabel = this._addInfoRow()
        this._shortcutInfoLabel = this._addInfoRow()
        this._portalInfoLabel = this._addInfoRow()
    }

    _addInfoRow() {
        const item = new PopupMenu.PopupBaseMenuItem({
            reactive: false,
            can_focus: false,
        })

        const label = new St.Label({
            style_class: 'macro-menu-subtitle',
            x_expand: true,
        })

        item.add_child(label)
        this.menu.addMenuItem(item)
        return label
    }

    _bindSettings() {
        this._settings.connectObject(
            `changed::${KEY_RECORD_SHORTCUT}`,
            () => {
                this._rebindShortcuts()
                this._syncUi()
            },
            `changed::${KEY_PLAYBACK_SHORTCUT}`,
            () => {
                this._rebindShortcuts()
                this._syncUi()
            },
            this)
    }

    _rebindShortcuts() {
        Main.wm.removeKeybinding(KEY_RECORD_SHORTCUT)
        Main.wm.removeKeybinding(KEY_PLAYBACK_SHORTCUT)

        Main.wm.addKeybinding(
            KEY_RECORD_SHORTCUT,
            this._settings,
            Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
            Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW,
            () => {
                this._toggleRecording()
            })

        Main.wm.addKeybinding(
            KEY_PLAYBACK_SHORTCUT,
            this._settings,
            Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
            Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW,
            () => {
                void this._togglePlayback()
            })
    }

    _toggleRecording() {
        if (this._status === STATUS.RECORDING) {
            this._stopRecording()
            return
        }

        this._cancelPlayback()
        this._startRecording()
    }

    async _togglePlayback() {
        if (this._status === STATUS.PREPARING || this._status === STATUS.PLAYING) {
            this._cancelPlayback()
            return
        }

        if (this._status === STATUS.RECORDING)
            this._stopRecording()

        await this._startPlayback()
    }

    _startRecording() {
        this._disconnectRecorder()

        this._lastError = ''
        this._status = STATUS.RECORDING
        this._macroEvents = []
        this._lastRecordTime = null
        const [pointerX, pointerY] = global.get_pointer()
        this._lastPointerX = pointerX
        this._lastPointerY = pointerY

        this._captureSignalId = global.stage.connect('captured-event', (_actor, event) => {
            return this._onCapturedEvent(event)
        })

        this._syncUi()
    }

    _stopRecording() {
        if (this._status !== STATUS.RECORDING)
            return

        this._disconnectRecorder()
        this._status = STATUS.IDLE
        this._lastError = ''
        this._syncUi()
    }

    _disconnectRecorder() {
        if (!this._captureSignalId)
            return

        global.stage.disconnect(this._captureSignalId)
        this._captureSignalId = 0
    }

    _onCapturedEvent(event) {
        switch (event.type()) {
        case Clutter.EventType.MOTION:
            this._recordMotion(event)
            break
        case Clutter.EventType.BUTTON_PRESS:
            this._recordPointerButton(event, BUTTON_PRESSED)
            break
        case Clutter.EventType.BUTTON_RELEASE:
            this._recordPointerButton(event, BUTTON_RELEASED)
            break
        case Clutter.EventType.KEY_PRESS:
            this._recordKey(event, KEY_PRESSED)
            break
        case Clutter.EventType.KEY_RELEASE:
            this._recordKey(event, KEY_RELEASED)
            break
        default:
            break
        }

        return Clutter.EVENT_PROPAGATE
    }

    _recordMotion(event) {
        const [x, y] = event.get_coords()
        const dx = x - this._lastPointerX
        const dy = y - this._lastPointerY

        this._lastPointerX = x
        this._lastPointerY = y

        if (dx === 0 && dy === 0)
            return

        this._recordEvent({
            type: 'motion',
            dx,
            dy,
        }, event.get_time())
    }

    _recordPointerButton(event, state) {
        const [x, y] = event.get_coords()
        this._lastPointerX = x
        this._lastPointerY = y

        const buttonCode = BUTTON_TO_PORTAL_CODE.get(event.get_button())
        if (!buttonCode)
            return

        this._recordEvent({
            type: 'button',
            buttonCode,
            state,
        }, event.get_time())
    }

    _recordKey(event, state) {
        const keysym = event.get_key_symbol()
        if (keysym === Clutter.KEY_F4 || keysym === Clutter.KEY_F5)
            return

        this._recordEvent({
            type: 'key',
            keycode: event.get_key_code(),
            keysym,
            state,
        }, event.get_time())
    }

    _recordEvent(payload, timestamp) {
        const delay = this._lastRecordTime === null
            ? 0
            : Math.max(0, timestamp - this._lastRecordTime)
        const lastEvent = this._macroEvents[this._macroEvents.length - 1] ?? null

        if (payload.type === 'motion' && delay === 0 && lastEvent?.type === 'motion') {
            lastEvent.dx += payload.dx
            lastEvent.dy += payload.dy
            this._lastRecordTime = timestamp
            return
        }

        this._macroEvents.push({
            ...payload,
            delay,
        })

        this._lastRecordTime = timestamp
    }

    _cancelPlayback() {
        this._playbackSerial++

        if (this._status !== STATUS.PREPARING && this._status !== STATUS.PLAYING)
            return

        this._status = STATUS.IDLE
        this._lastError = ''
        this._syncUi()
    }

    async _startPlayback() {
        if (this._macroEvents.length === 0) {
            Main.notifyError(
                _('No macro recorded'),
                _('Press F4 to record a macro before starting playback.'))
            return
        }

        const serial = ++this._playbackSerial
        this._status = STATUS.PREPARING
        this._lastError = ''
        this._syncUi()

        try {
            await this._session.start()

            if (this._destroyed || serial !== this._playbackSerial)
                return

            this._status = STATUS.PLAYING
            this._syncUi()

            for (const macroEvent of this._macroEvents) {
                if (this._destroyed || serial !== this._playbackSerial)
                    return

                await waitMs(macroEvent.delay)

                if (this._destroyed || serial !== this._playbackSerial)
                    return

                await this._playMacroEvent(macroEvent)
            }

            if (this._destroyed || serial !== this._playbackSerial)
                return

            this._status = STATUS.IDLE
            this._syncUi()
        } catch (error) {
            if (this._destroyed || serial !== this._playbackSerial)
                return

            await this._stopFromError(error)
        }
    }

    async _playMacroEvent(macroEvent) {
        switch (macroEvent.type) {
        case 'motion':
            await this._session.movePointer(macroEvent.dx, macroEvent.dy)
            return
        case 'button':
            await this._session.notifyPointerButton(macroEvent.buttonCode, macroEvent.state)
            return
        case 'key':
            if (macroEvent.keycode > 0) {
                await this._session.notifyKeyboardKeycode(macroEvent.keycode, macroEvent.state)
                return
            }

            if (macroEvent.keysym > 0) {
                await this._session.notifyKeyboardKeysym(macroEvent.keysym, macroEvent.state)
                return
            }

            throw new Error(_('Recorded key event has no usable key identifier.'))
        default:
            throw new Error(_('Unknown macro event type.'))
        }
    }

    async _stopFromError(error) {
        this._playbackSerial++
        this._disconnectRecorder()
        this._status = STATUS.ERROR
        this._lastError = describeError(error)
        await this._session.stop()
        this._syncUi()

        Main.notifyError(_('Macro recorder error'), this._lastError)
    }

    _statusText() {
        switch (this._status) {
        case STATUS.RECORDING:
            return `${_('Recording')} - ${formatEventCount(this._macroEvents.length)}`
        case STATUS.PREPARING:
            return _('Requesting GNOME keyboard and pointer access...')
        case STATUS.PLAYING:
            return `${_('Playing back')} - ${formatEventCount(this._macroEvents.length)}`
        case STATUS.ERROR:
            return this._lastError
        case STATUS.IDLE:
        default:
            if (this._macroEvents.length === 0)
                return _('Press F4 to record your first macro.')

            return _('Ready to replay the last recorded macro.')
        }
    }

    _syncUi() {
        const recordShortcut = formatShortcut(this._settings, KEY_RECORD_SHORTCUT)
        const playbackShortcut = formatShortcut(this._settings, KEY_PLAYBACK_SHORTCUT)

        this._statusDescription.text = this._statusText()
        this._macroInfoLabel.text = this._macroEvents.length > 0
            ? `${_('Last macro')}: ${formatEventCount(this._macroEvents.length)}`
            : _('Last macro: none recorded yet')
        this._shortcutInfoLabel.text =
            `${recordShortcut} ${_('starts or stops recording')}. ` +
            `${playbackShortcut} ${_('starts or stops playback')}.`
        this._portalInfoLabel.text =
            _('The first playback after enabling the extension may show a GNOME access prompt.')

        this.remove_style_class_name('macro-preparing')
        this.remove_style_class_name('macro-recording')
        this.remove_style_class_name('macro-playing')

        if (this._status === STATUS.PREPARING)
            this.add_style_class_name('macro-preparing')
        else if (this._status === STATUS.RECORDING)
            this.add_style_class_name('macro-recording')
        else if (this._status === STATUS.PLAYING)
            this.add_style_class_name('macro-playing')
    }

    destroy() {
        this._destroyed = true
        this._playbackSerial++
        this._disconnectRecorder()
        Main.wm.removeKeybinding(KEY_RECORD_SHORTCUT)
        Main.wm.removeKeybinding(KEY_PLAYBACK_SHORTCUT)
        this._settings.disconnectObject(this)
        this._session.destroy()
        super.destroy()
    }
})

export default class WaylandAutoclickerExtension extends Extension {
    enable() {
        this._indicator = new MacroIndicator(this)
        Main.panel.addToStatusArea('wayland-autoclicker', this._indicator)
    }

    disable() {
        this._indicator.destroy()
        this._indicator = null
    }
}
